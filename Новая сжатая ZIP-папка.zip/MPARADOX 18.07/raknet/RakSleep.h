#ifndef __RAK_SLEEP_H
#define __RAK_SLEEP_H

void RakSleep(unsigned int ms);

#endif
