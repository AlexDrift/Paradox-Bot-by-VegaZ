extern char AuthKeyTable[256][2][128];
