/*
	Updated to 0.3.7 by P3ti
*/

extern HWND hwnd,tp1,tp2,tp3,hEdit1,hList,hProgress,hProgress2,hProgress3,hChangeip,hMyip,hAutorec,hEdit2,hHostn,hList2,hEdit12,hEdit13,hEdit14;
extern HINSTANCE g_hInst;
extern HINSTANCE HIDD_DIALOG1;
extern BOOL CALLBACK call_IDD_DIALOG1(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK TeleportMenuProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
DWORD WINAPI TeleportMenuThread(PVOID);
void SetUpWindow(HINSTANCE hInstance);
void SetUpRaksamp(HINSTANCE hInstance);