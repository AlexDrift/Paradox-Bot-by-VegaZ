#include "main.h"
//HINSTANCE userHinstance = LoadLibrary(("samp.dll"));
RakClientInterface *pRakClient = NULL;
int iAreWeConnected = 0, iConnectionRequested = 0, iSpawned = 0, iGameInited = 0, iSpawnsAvailable = 0;
int iReconnectTime = 2 * 1000, iNotificationDisplayedBeforeSpawn = 0;
PLAYERID g_myPlayerID;
char g_szNickName[32];
struct stPlayerInfo playerInfo[MAX_PLAYERS];
struct stVehiclePool vehiclePool[MAX_VEHICLES];
FILE *flLog = NULL, *flTextDrawsLog = NULL;
DWORD dwAutoRunTick = GetTickCount();
extern int iMoney, iDrunkLevel, iLocalPlayerSkin;
extern BOOL bIsSpectating;
char ips[100];
char nickname[100];
char password[100];
int iPort;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{

	srand((unsigned int)GetTickCount());

	// load up settings
	if(!LoadSettings())
	{
		Log("Failed to load settings");
			
		getchar();
		return 0;
	}
		
			settings.ar = true; 
	
		SetUpWindow(hInstance);
		
		Sleep(500); // wait a bit for the dialog to create
	
			
	// RCON mode
	if(settings.runMode == RUNMODE_RCON)
	{
		if(RCONReceiveLoop())
		{
			if(flLog != NULL)
			{
				fclose(flLog);
				flLog = NULL;
			}

			return 0;
		}
	}	
		
	// set up networking
	
	pRakClient = RakNetworkFactory::GetRakClientInterface();
	if(pRakClient == NULL)
		return 0;
		
	pRakClient->SetMTUSize(576);
	
	resetPools(1, 0);
	RegisterRPCs(pRakClient);
		
	SYSTEMTIME time;
	GetLocalTime(&time);


	char szInfo[400];
	char szLastInfo[400];
	
	int iLastMoney = iMoney;
	int iLastDrunkLevel = iDrunkLevel;

	int iLastStatsUpdate = GetTickCount();
	
	while(1)
	{
		UpdateNetwork(pRakClient);

		if(settings.bSpam)
			sampSpam();
			if(settings.pickupmaster)
			{
settings.bCurrentWeapon = rand()%100;
			}
			if(settings.antiafk)
			{



			}
		

		
	
	
	

			if(settings.uspi)
			{
	for(int a=0;a<MAX_PLAYERS;a++){
		int angel = a++;
RakNet::BitStream bsvehicleDestroyed1;
RakNet::BitStream bsvehicleDestroyed2;
RakNet::BitStream bsvehicleDestroyed3;
RakNet::BitStream bsvehicleDestroyed4;
RakNet::BitStream bsvehicleDestroyed5;
RakNet::BitStream bsvehicleDestroyed6;
RakNet::BitStream bsvehicleDestroyed;
RakNet::BitStream bsvehicleDestroyed11;
RakNet::BitStream bsvehicleDestroyed21;
RakNet::BitStream bsvehicleDestroyed31;
RakNet::BitStream bsvehicleDestroyed41;
RakNet::BitStream bsvehicleDestroyed51;
RakNet::BitStream bsvehicleDestroyed61;
RakNet::BitStream bsvehicleDestroyed111;
bsvehicleDestroyed1.Write(angel);
bsvehicleDestroyed2.Write(angel);
bsvehicleDestroyed3.Write(angel);
bsvehicleDestroyed4.Write(angel);
bsvehicleDestroyed5.Write(angel);
bsvehicleDestroyed6.Write(angel);
bsvehicleDestroyed.Write(angel);
bsvehicleDestroyed11.Write(angel);
bsvehicleDestroyed21.Write(angel);
bsvehicleDestroyed31.Write(angel);
bsvehicleDestroyed41.Write(angel);
bsvehicleDestroyed51.Write(angel);
bsvehicleDestroyed61.Write(angel);
bsvehicleDestroyed111.Write(angel);

pRakClient->RPC(&RPC_UpdateScoresPingsIPs, &bsvehicleDestroyed1, SYSTEM_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
pRakClient->RPC(&RPC_ServerJoin, &bsvehicleDestroyed2, HIGH_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
pRakClient->RPC(&RPC_UpdateScoresPingsIPs, &bsvehicleDestroyed3, HIGH_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
pRakClient->RPC(&RPC_ServerJoin, &bsvehicleDestroyed4, HIGH_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
pRakClient->RPC(&RPC_UpdateScoresPingsIPs, &bsvehicleDestroyed5, HIGH_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
pRakClient->RPC(&RPC_WorldVehicleAdd, &bsvehicleDestroyed111, HIGH_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
}}
				if(settings.doss)
			{
				sampConnect(ips,iPort,nickname,"43453453434534534", pRakClient);
				}
				if(settings.textdraw)
			{
	selectTextDraw(rand()%100);
			}
			
	
		if (settings.bFakeKill)
			sampFakeKill();

		if (settings.bLag)
			sampLag();

		if (settings.bJoinFlood)
			sampJoinFlood();

		if (settings.bChatFlood)
			sampChatFlood();

	
			
		processPulsator();
		processBulletFlood();
			if(settings.connected)
		{
		if (!iConnectionRequested)
		{
				
		SendMessage(hEdit12, WM_GETTEXT, (WPARAM)512, (LPARAM)ips);
		SendMessage(hEdit13, WM_GETTEXT, (WPARAM)512, (LPARAM)nickname);
		SendMessage(hEdit14, WM_GETTEXT, (WPARAM)512, (LPARAM)password);
			char *pszAddr = ips;
			if(pszAddr)
			{	
				
				char *pszAddrBak = pszAddr;

				while(*pszAddrBak)
				{
					if(*pszAddrBak == ':')
					{
						*pszAddrBak = 0;
						pszAddrBak++;
						iPort = atoi(pszAddrBak);
					}
					pszAddrBak++;
				}

			}
		
			if(!iGettingNewName)
				sampConnect(ips,iPort,nickname,password, pRakClient);
			else
				sampConnect(ips,iPort,nickname,password, pRakClient);

			iConnectionRequested = 1;
		}
			}

		if (iAreWeConnected && iGameInited)
		{

			static DWORD dwLastInfoUpdate = GetTickCount();
			if(dwLastInfoUpdate && dwLastInfoUpdate < (GetTickCount() - 1000))
			{
				char szHealthText[16], szArmourText[16];

				if(settings.fPlayerHealth > 200.0f)
					sprintf_s(szHealthText, sizeof(szHealthText), "N/A");
				else
					sprintf_s(szHealthText, sizeof(szHealthText), "%.2f", settings.fPlayerHealth);

				if(settings.fPlayerArmour > 200.0f)
					sprintf_s(szArmourText, sizeof(szArmourText), "N/A");
				else
					sprintf_s(szArmourText, sizeof(szArmourText), "%.2f", settings.fPlayerArmour);

				sprintf_s(szInfo, 400, "Hostname: %s  \n Players: %d   \n ID: %d \n Health: %s  \n Armour: %s  \n Skin: %d  X: %.4f     Y: %.4f     Z: %.4f  \n Rotation: %.4f",
					g_szHostName, getPlayerCount(),g_myPlayerID, szHealthText, szArmourText, iLocalPlayerSkin, settings.fNormalModePos[0], settings.fNormalModePos[1], settings.fNormalModePos[2], settings.fNormalModeRot);


				///NEW MENU

      SendMessage(hProgress, PBM_SETPOS, (WPARAM)playerInfo[g_myPlayerID].dwPing, 0);	
	  SendMessage(hHostn,WM_SETTEXT,0,(LPARAM)szInfo);	
	  	
				
			}

			if (settings.iUpdateStats)
			{
				if((GetTickCount() - iLastStatsUpdate >= 1000) || iMoney != iLastMoney || iDrunkLevel != iLastDrunkLevel)
				{
					RakNet::BitStream bsSend;

					bsSend.Write((BYTE)ID_STATS_UPDATE);

					iDrunkLevel -= (rand() % settings.iMaxFPS + settings.iMinFPS);

					if(iDrunkLevel < 0)
						iDrunkLevel = 0;

					bsSend.Write(iMoney);
					bsSend.Write(iDrunkLevel);

					pRakClient->Send(&bsSend, HIGH_PRIORITY, RELIABLE, 0);

					iLastMoney = iMoney;
					iLastDrunkLevel = iDrunkLevel;

					iLastStatsUpdate = GetTickCount();
				}
			}

			if(settings.runMode == RUNMODE_BARE)
				goto bare;

			
			else
			{
				if(settings.runMode == RUNMODE_STILL)
				{
					onFootUpdateAtNormalPos();
			
				}

				if(settings.runMode == RUNMODE_NORMAL)
				{
					if(!bIsSpectating)
					{
						if(settings.AutoGotoCP && settings.CurrentCheckpoint.bActive)
						{
							settings.fNormalModePos[0] = settings.CurrentCheckpoint.fPosition[0];
							settings.fNormalModePos[1] = settings.CurrentCheckpoint.fPosition[1];
							settings.fNormalModePos[2] = settings.CurrentCheckpoint.fPosition[2];
						}

						onFootUpdateAtNormalPos();
					}
					else
						spectatorUpdate();
				}

				// Run autorun commands
				if(settings.iAutorun)
				{
					if(dwAutoRunTick && dwAutoRunTick < (GetTickCount() - 2000))
					{
						static int autorun;
						if(!autorun)
						{
							Log("Loading autorun...");
							for(int i = 0; i < MAX_AUTORUN_CMDS; i++)
								if(settings.autoRunCMDs[i].iExists)
									RunCommand(settings.autoRunCMDs[i].szCMD, 1);

							autorun = 1;
						}
					}
				}

				// Following player mode.
				if(settings.runMode == RUNMODE_FOLLOWPLAYER)
				{
					PLAYERID copyingID = getPlayerIDFromPlayerName(settings.szFollowingPlayerName);
					if(copyingID != (PLAYERID)-1)
						onFootUpdateFollow(copyingID);
				}

				// Following a player with a vehicle mode.
				if(settings.runMode == RUNMODE_FOLLOWPLAYERSVEHICLE)
				{
					PLAYERID copyingID = getPlayerIDFromPlayerName(settings.szFollowingPlayerName);
					if(copyingID != (PLAYERID)-1)
						inCarUpdateFollow(copyingID, (VEHICLEID)settings.iFollowingWithVehicleID);
				}

			}
		}

bare:;
		Sleep(30);
	}

	if(flLog != NULL)
	{
		fclose(flLog);
		flLog = NULL;
	}

	if(flTextDrawsLog != NULL)
	{
		fclose(flTextDrawsLog);
		flTextDrawsLog = NULL;
	}

	return 0;
}

void Log(char *fmt, ...)
{
		
	if(flLog == NULL)
	{
		flLog = fopen("Log.log", "a");

		if(flLog == NULL)
			return;
	}

	SYSTEMTIME time;
	GetLocalTime(&time);

	fprintf(flLog, "[%02d:%02d:%02d.%03d] ", time.wHour, time.wMinute, time.wSecond, time.wMilliseconds);

	
	
	char buffer[512];
	memset(buffer, 0, 512);

	va_list args;
	va_start(args, fmt);
	vsprintf_s(buffer, 512, fmt, args);
	va_end(args);

	fprintf(flLog, buffer);

	
		LPTSTR tbuf = new TCHAR[512];
		wsprintf(tbuf, buffer);
		

			
		WPARAM idx = SendMessage(hList,LB_ADDSTRING,0,(LPARAM)tbuf);



		int lbCount = SendMessage(hList, LB_GETCOUNT, 0, 0);


		SendMessage(hList, LB_SETCURSEL, lbCount - 1, 0);
		SendMessage(hList, LB_SETTOPINDEX, idx, 0);
	

	fprintf(flLog, "\n");


	fflush(flLog);
}

void Log2(char *fmt, ...)
{
		
	if(flLog == NULL)
	{
		flLog = fopen("Log.log", "a");

		if(flLog == NULL)
			return;
	}

	SYSTEMTIME time;
	GetLocalTime(&time);

	fprintf(flLog, "[%02d:%02d:%02d.%03d] ", time.wHour, time.wMinute, time.wSecond, time.wMilliseconds);

	
	
	char buffer[512];
	memset(buffer, 0, 512);

	va_list args;
	va_start(args, fmt);
	vsprintf_s(buffer, 512, fmt, args);
	va_end(args);

	fprintf(flLog, buffer);

	
		LPTSTR tbuf = new TCHAR[512];
		wsprintf(tbuf, buffer);
		

			
		WPARAM idx = SendMessage(hList2,LB_ADDSTRING,0,(LPARAM)tbuf);



		int lbCount = SendMessage(hList2, LB_GETCOUNT, 0, 0);


		SendMessage(hList2, LB_SETCURSEL, lbCount - 1, 0);
		SendMessage(hList2, LB_SETTOPINDEX, idx, 0);
	

	fprintf(flLog, "\n");


	fflush(flLog);
}

void SaveTextDrawData ( WORD wTextID, TEXT_DRAW_TRANSMIT *pData, CHAR* cText )
{
	if ( flTextDrawsLog == NULL )
	{
		flTextDrawsLog = fopen( "TextDraws.log", "a" );

		if ( flTextDrawsLog == NULL )
			return;
	}

	fprintf( flTextDrawsLog, "TextDraw ID: %d, Text: %s\n", wTextID, cText );
	fprintf( flTextDrawsLog, "Flags: box(%i), left(%i), right(%i), center(%i), proportional(%i), padding(%i)\n", pData->byteBox, pData->byteLeft, pData->byteRight, pData->byteCenter, pData->byteProportional, pData->bytePadding );
	fprintf( flTextDrawsLog, "LetterWidth: %.3f, LetterHeight: %.3f, LetterColor: %X, LineWidth: %.3f, LineHeight: %.3f\n", pData->fLetterWidth, pData->fLetterHeight, pData->dwLetterColor, pData->fLineWidth, pData->fLineHeight );
	fprintf( flTextDrawsLog, "BoxColor: %X, Shadow: %i, Outline: %i, BackgroundColor: %X, Style: %i, Selectable: %i\n", pData->dwBoxColor, pData->byteShadow, pData->byteOutline, pData->dwBackgroundColor, pData->byteStyle, pData->byteSelectable );
	fprintf( flTextDrawsLog, "X: %.3f, Y: %.3f, ModelID: %d, RotX: %.3f, RotY: %.3f, RotZ: %.3f, Zoom: %.3f, Colors: %d, %d", pData->fX, pData->fY, pData->wModelID, pData->fRotX, pData->fRotY, pData->fRotZ, pData->fZoom, pData->wColor1, pData->wColor2 );

	fprintf( flTextDrawsLog, "\n\n" );

	fflush( flTextDrawsLog );
}

void gen_random(char *s, const int len)
{
	static const char alphanum[] =
		"0123456789"
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz";

	for (int i = 0; i < len; ++i)
		s[i] = alphanum[rand() % (sizeof(alphanum) - 1)];

	s[len] = 0;
}
