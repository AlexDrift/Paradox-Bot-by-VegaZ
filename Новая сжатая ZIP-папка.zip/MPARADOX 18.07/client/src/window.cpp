/*
	Updated to 0.3.7 by P3ti
*/
//includes
#include "main.h"
#include <locale.h> 
#include <winsock.h>
#include <windows.h> 
#include <fstream> 
#include <iostream> 
#include <string.h> 
// Globals
HWND hwnd,tp1,tp2,tp3,hEdit1,hList,hProgress,hProgress2,hProgress3,hChangeip,hMyip,hAutorec,hEdit2,hHostn,hList2,hEdit12,hEdit13,hEdit14;
const int WSVer = 0x101;
WSAData wsaData;
hostent *h;
char Buf[128];
HINSTANCE HIDD_DIALOG1;
BOOL CALLBACK call_IDD_DIALOG1(HWND,UINT,WPARAM,LPARAM);
HINSTANCE HIDD_DIALOG2;
BOOL CALLBACK call_IDD_DIALOG2(HWND,UINT,WPARAM,LPARAM);
BOOL bTeleportMenuActive = NULL;
HFONT hTeleportMenuFont = NULL;
HANDLE hTeleportMenuThread = NULL;
HWND hwndTeleportMenu = NULL;
HWND hwndPacketMenu = NULL;
HDC hdcScreen2;
using namespace std; 
static HBRUSH hBrush = CreateSolidBrush(RGB(255,255,255));
char str[512];
CHAR s_text_1[] = {"You text"};
CHAR s_text_3[] = {"127.0.0.1:7777"};
BOOL CALLBACK call_IDD_DIALOG1(HWND handle22,UINT mensaje,WPARAM wParam,LPARAM lParam)
{

	switch(mensaje)
	{
	case WM_INITDIALOG:	{
     	hEdit1 = GetDlgItem(handle22,IDC_EDIT1);
		hList = GetDlgItem(handle22,IDC_LIST1);
	   hList2 = GetDlgItem(handle22,IDC_LIST43);
		hEdit2 = GetDlgItem(handle22,IDC_EDIT2);
		hProgress = GetDlgItem(handle22,IDC_PROGRESS1);
		hChangeip = GetDlgItem(handle22,IDC_EDIT3);
		hMyip = GetDlgItem(handle22,IDC_IPADDRESS1);
		hAutorec = GetDlgItem(handle22,IDC_CHECK2);
		hHostn = GetDlgItem(handle22,IDC_STATIC14);
		tp1 =  GetDlgItem(handle22,IDC_EDIT4);
		tp2 =  GetDlgItem(handle22,IDC_EDIT5);
		tp3 =  GetDlgItem(handle22,IDC_EDIT6);
		SendMessage(hProgress, PBM_SETRANGE, 0, MAKELPARAM(0,100));
		SendMessage(hEdit1,WM_SETTEXT,0,(LPARAM)s_text_1);	
		SendMessage(hEdit2,WM_SETTEXT,0,(LPARAM)"You_Name");
		SendMessage(hChangeip,WM_SETTEXT,0,(LPARAM)"127.0.0.1:7777");	
		SendMessage(hAutorec, BM_SETCHECK, BST_CHECKED, 0);
if (WSAStartup(WSVer, &wsaData) == 0)
{
if (gethostname(&Buf[0], 128) == 0)
{
h = gethostbyname(&Buf[0]);
if (h != NULL) SendMessage(hMyip,WM_SETTEXT,0,(LPARAM)inet_ntoa (*(reinterpret_cast<in_addr *>(*(h->h_addr_list)))));	
else MessageBox(0,"ERROR #121.",0,0);
}
WSACleanup;
}
hdcScreen2 = GetDC(HWND_DESKTOP);
			break;
						}	
				
case WM_CTLCOLORLISTBOX://list box color (all)
{   HDC hdcStatic = (HDC) wParam;
    SetTextColor(hdcStatic, RGB(0,0,0));
    SetBkColor(hdcStatic, RGB(255,255,255)); 
    return (INT_PTR)hBrush; 
}
	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
			case IDC_BUTTON1:
				{
			sampDisconnect(0);
			resetPools(1, 1);
			Beep(500,100);
				}
			    break;
					case IDC_BUTTON2:
				{
                gen_random(g_szNickName, 16);
				char szNewNick[24];
				iGettingNewName = true;
				sprintf(szNewNick, "%s", g_szNickName);
				Log(" * Bot Connectet %s", szNewNick);
				strcpy(g_szNickName, szNewNick);
				pRakClient = RakNetworkFactory::GetRakClientInterface();
				pRakClient->SetMTUSize(576);
				RegisterRPCs(pRakClient);
				UpdateNetwork(pRakClient);
				resetPools(1, 0);	
				Beep(500,100);
				}
			    break;
					case IDC_BUTTON3:
				{
			  RakNet::BitStream bsSpawnRequest;
       bsSpawnRequest.Write(rand()%7);
       pRakClient->RPC(&RPC_RequestClass, &bsSpawnRequest, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
	              RakNet::BitStream bsSendSpawn;	
	    bsSendSpawn.Write(rand()%7);
       pRakClient->RPC(&RPC_Spawn, &bsSendSpawn, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
				Beep(500,100);
				}
			    break;
					case IDC_BUTTON4://send message
				{
			    if(GetWindowTextLength(hEdit1) == 0)
				break;
			    SendMessage(hEdit1, WM_GETTEXT, (WPARAM)512, (LPARAM)str);
			    RunCommand(str, 0);
		        SetFocus(hEdit1);
				Beep(500,100);
				}
			    break;
				case IDC_BUTTON5://fake out
				{
				RakNet::BitStream bs;
	          	bs.Write((BYTE)ID_CONNECTION_LOST);
		        pRakClient->Send(&bs, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
			    Log("[Paradox Bot]Successfully!");
				Beep(500,100);
				}
			    break;
						case IDC_BUTTON6://NICK PARSER
				{
		        Log2("[Paradox Bot]Successfully!");
				Beep(500,100);
				}
			    break;
					case IDC_BUTTON7://spawn
				{

					   RakNet::BitStream bsSpawnRequest;
       bsSpawnRequest.Write(rand()%7);
       pRakClient->RPC(&RPC_RequestClass, &bsSpawnRequest, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
	              RakNet::BitStream bsSendSpawn;	
	    bsSendSpawn.Write(rand()%7);
       pRakClient->RPC(&RPC_Spawn, &bsSendSpawn, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
 		Log(" * ���������.");
 	             Log("[Paradox Bot]Spawned");
				}
			    break;
	                case IDC_BUTTON9://spawn
	         	{
	            if(GetWindowTextLength(hEdit2) < 3)
		        break;
		        char str[512];
		        SendMessage(hEdit2, WM_GETTEXT, (WPARAM)512, (LPARAM)str);
		        char szNewNick[24];
		        iGettingNewName = true;
		        sprintf(szNewNick, "%s", str);
		        Log("[Paradox Bot]Name changed:%s.", szNewNick);
		        strcpy(g_szNickName, szNewNick);
		        resetPools(1, 0);
			    Beep(500,100);
		}
	    break;
		case IDC_BUTTON8://spawn
		{
		if(GetWindowTextLength(hChangeip) < 10)
		break;
		char ip[512];
		SendMessage(hChangeip, WM_GETTEXT, (WPARAM)512, (LPARAM)ip);
		Log("[Paradox Bot]Connecting to %s.", ip);
		char *pszAddr = ip;
		iGettingNewName = true;
		int iPort;
		char *pszAddrBak = pszAddr;
        while(*pszAddrBak)
		{
		if(*pszAddrBak == ':')
		{
		*pszAddrBak = 0;
		pszAddrBak++;
		iPort = atoi(pszAddrBak);
		}
		pszAddrBak++;
	    }
        strcpy(settings.server.szAddr, pszAddr);
		settings.server.iPort = iPort;
		resetPools(1, 0);
			Beep(500,100);
		}
	    break;
		case IDC_BUTTON12://spawn
		{
	    char x[41];
	    char y[41];
		char z[41];
        SendMessage(tp1, WM_GETTEXT, (WPARAM)11, (LPARAM)x);
	    SendMessage(tp2, WM_GETTEXT, (WPARAM)11, (LPARAM)y);
     	SendMessage(tp3, WM_GETTEXT, (WPARAM)11, (LPARAM)z);
        settings.fNormalModePos[0] = atof(x);
        settings.fNormalModePos[1] =  atof(y);
        settings.fNormalModePos[2] =  atof(z);
	    Log("[Paradox Bot]Teleported.");
		Beep(500,100);
	    }
    break;
		case IDC_BUTTON11://spawn
		{
			 if (settings.doss) { 
  Log("[Paradox Bot]Pickup Master stopped.");
           	settings.doss = false; 
         }else{ 
  Log("[Paradox Bot]Pickup Master launched.");
           settings.doss = true; 
		 }
				
			 	Beep(500,100);
      }
    break;
	
					case IDC_CHECK1://spawn
				{
						
  if (settings.packetlog) { 
           		settings.packetlog = false; 
         }else{ 
           settings.packetlog = true; 
		
		 }
  	Beep(500,100);
				}
			    break;
								case IDC_CHECK2://spawn
				{if (settings.ar){settings.ar = false;}else{settings.ar = true;}}
			    break;

				case IDC_CHECK3://spawn
				{
				   if (settings.textdraw) { 
  Log("[Paradox Bot]Textdraw selector stopped.");
           	settings.textdraw = false; 
         }else{ 
  Log("[Paradox Bot]Textdraw selector launched.");
           settings.textdraw = true; 
		 }
				Beep(500,100);
				}
			    break;

					case IDC_CHECK4://spawn
				{
				    if (settings.AutoGotoCP) { 
  Log("[Paradox Bot]Automatic Checkpoint Teleporter stopped.");
           		settings.AutoGotoCP = false; 
         }else{ 
Log("[Paradox Bot]Automatic Checkpoint Teleporter  launched.");
           settings.AutoGotoCP = true; 
		 }
				Beep(500,100);	}
			    break;

				case IDC_CHECK5://spawn
				{
				    if (settings.pickupmaster) { 
  Log("[Paradox Bot]Pickup Master stopped.");
           	settings.pickupmaster = false; 
         }else{ 
  Log("[Paradox Bot]Pickup Master launched.");
           settings.pickupmaster = true; 
		 }
					Beep(500,100);}
			    break;
					case IDC_CHECK6://spawn
				{
					 if (settings.antiafk) { 
  Log("[Paradox Bot]Pickup Master stopped.");
           	settings.antiafk = false; 
         }else{ 
  Log("[Paradox Bot]Pickup Master launched.");
           settings.antiafk = true; }
	Beep(500,100);
				}
			    break;
			
					case IDCANCEL://exit process 
				{
						sampDisconnect(0);
						PostQuitMessage(0);
						ExitProcess(0);
							Beep(500,100);
				}

			    break;
		}
	}
	return false;
}

//connector
BOOL CALLBACK call_IDD_DIALOG2(HWND handle222,UINT mensaje,WPARAM wParam,LPARAM lParam)
{

	switch(mensaje)
	{
	case WM_INITDIALOG:	{
     		hEdit12 = GetDlgItem(handle222,IDC_EDIT112);
			SendMessage(hEdit12,WM_SETTEXT,0,(LPARAM)s_text_3);	
			hEdit13 = GetDlgItem(handle222,IDC_EDIT113);
			SendMessage(hEdit13,WM_SETTEXT,0,(LPARAM)"You_Nickname");	
				hEdit14 = GetDlgItem(handle222,IDC_EDIT114);
			break;
						}	
				
case WM_CTLCOLORLISTBOX://list box color (all)
{   HDC hdcStatic = (HDC) wParam;
    SetTextColor(hdcStatic, RGB(0,0,0));
    SetBkColor(hdcStatic, RGB(255,255,255)); 
    return (INT_PTR)hBrush; 
}
	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
			case IDC_BUTTON111:
				{
					EndDialog(handle222,0);
					settings.connected = true; 
					DialogBox(HIDD_DIALOG1,MAKEINTRESOURCE(IDD_DIALOG1),0,call_IDD_DIALOG1);
				}
			    break;
				
						case IDCANCEL://exit process 
				{
						sampDisconnect(0);
						PostQuitMessage(0);

						ExitProcess(0);
							Beep(500,100);
				}

			    break;
		}
	}
	return false;
}
DWORD WINAPI windowThread(PVOID)
{
	
		DialogBox(HIDD_DIALOG2,MAKEINTRESOURCE(IDD_DIALOG2),0,call_IDD_DIALOG2);
return 0;
}

DWORD WINAPI windowThread2(PVOID)
{
	DialogBox(HIDD_DIALOG1,MAKEINTRESOURCE(IDD_DIALOG1),0,call_IDD_DIALOG1);
	
return 0;
}

void SetUpWindow(HINSTANCE hInstance)
{
	CreateThread(NULL, 0, windowThread, NULL, 0, NULL);
}

void SetUpRaksamp(HINSTANCE hInstance)
{
	CreateThread(NULL, 0, windowThread2, NULL, 0, NULL);
}
LRESULT CALLBACK TeleportMenuProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	HWND hwndEditBox = GetDlgItem(hwnd, IDE_INPUTEDIT);
	HWND hwndListBox = GetDlgItem(hwnd, IDL_LISTBOX);
	WORD wSelection;
	char szResponse[257];

	switch(msg)
	{
	case WM_CREATE:
		{

			HINSTANCE hInst = GetModuleHandle(NULL);
			
			hwndListBox = CreateWindowEx(NULL, "LISTBOX", "",
				WS_CHILD | WS_VISIBLE | LBS_NOTIFY | WS_VSCROLL | WS_BORDER | LBS_HASSTRINGS,
				10, 10, 375, 225, hwnd, (HMENU)IDL_LISTBOX, hInst, NULL);

			for(int i = 0; i < MAX_TELEPORT_ITEMS; i++)
			{
				if(settings.TeleportLocations[i].bCreated)
				{
					int id = SendMessage(hwndListBox, LB_ADDSTRING, 0, (LPARAM)settings.TeleportLocations[i].szName);
					SendMessage(hwndListBox, LB_SETITEMDATA, id, (LPARAM)id);
				}
			}
						
			CreateWindowEx(NULL, "BUTTON", "Teleport", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
				100, 230, 100, 24, hwnd, (HMENU)IDB_BUTTON1, hInst, NULL);

			CreateWindowEx(NULL, "BUTTON", "Cancel", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
				210, 230, 100, 24, hwnd, (HMENU)IDB_BUTTON2, hInst, NULL);
		}
		break;

	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
					
		
		break;

				case IDB_BUTTON1:
					wSelection = (WORD)SendMessage(hwndListBox, LB_GETCURSEL, 0, 0);
					if(wSelection != (WORD)-1)
					{
						SendMessage(hwndListBox, LB_GETTEXT, wSelection, (LPARAM)szResponse);
						useTeleport(wSelection);
						PostQuitMessage(0);
					}
					break;

				case IDB_BUTTON2:
					GetWindowText(hwndEditBox, szResponse, 257);
					PostQuitMessage(0);
					break;
			}
		}

		break;

	case WM_PAINT:
		{
			RECT rect;
			GetClientRect(hwnd, &rect);
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC hdcMem = CreateCompatibleDC(hdc);
			DeleteDC(hdcMem);
			EndPaint(hwnd, &ps);
		}
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}

	return 0;
}

DWORD WINAPI TeleportMenuThread(PVOID)
{
	WNDCLASSEX wc;
	MSG Msg;
	HINSTANCE hInstance = GetModuleHandle(NULL);
	RECT conRect;

		GetWindowRect(hwnd, &conRect);

	wc.cbSize        = sizeof(WNDCLASSEX);
	wc.style         = 0;
	wc.lpfnWndProc   = TeleportMenuProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
//	wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszMenuName  = NULL;
	wc.lpszClassName = "teleportMenuWndClass";
//	wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

	if(!RegisterClassEx(&wc))
		return 0;

	hTeleportMenuFont = CreateFont(18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "System");

	hwndTeleportMenu = CreateWindowEx(NULL, "teleportMenuWndClass", "Teleports", NULL,
		conRect.right, conRect.top, 400, 300, NULL, NULL, hInstance, NULL);

	if(hwndTeleportMenu == NULL)
		return 0;

	ShowWindow(hwndTeleportMenu, 1);
	UpdateWindow(hwndTeleportMenu);
	SetForegroundWindow(hwndTeleportMenu);

	while(GetMessage(&Msg, NULL, 0, 0) > 0)
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}

	bTeleportMenuActive = 0;
	SendMessage(hwndTeleportMenu, WM_DESTROY, 0, 0);
	DestroyWindow(hwndTeleportMenu);
	UnregisterClass("teleportMenuWndClass", GetModuleHandle(NULL));
	hTeleportMenuFont = NULL;
	TerminateThread(hTeleportMenuThread, 0);

	return 0;
}

