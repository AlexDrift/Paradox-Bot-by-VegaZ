/*
	Updated to 0.3.7 by P3ti
*/

void SetUpConsole();
