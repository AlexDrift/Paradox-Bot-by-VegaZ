/*
	Updated to 0.3.7 by P3ti
*/

void LoadBanList();

void SendClientMessage(PLAYERID playerID, DWORD dwColor, char* szMessage, ...);
void SendChatMessage(PLAYERID playerID, char *szText, BYTE byteTextLen, int toAll);
