/*
	Updated to 0.3.7 by P3ti
*/

void generateAndLoadInternalScript(lua_State *L);
